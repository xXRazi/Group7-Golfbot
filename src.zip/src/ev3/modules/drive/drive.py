class Module:
    pass